<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/{path?}', function () {
    return view('welcome');
})->where('path', 'welcome');

Route::get('/dosen', function () {
    $data = [
        'Abdul Gani', 'Abdul Rauf', 'Imam Samudra', 'Muklas', 'Ali Imron', 
        'Amrozi', 'Bambang Setio', 'Andi Hidayat', 'Arnasan', 'Budi Wibowo'
    ];

    return view('dosen', ['data' => $data]);
});

Route::get('/mahasiswa', function () {
    $data = [
        'Brook', 'Franky', 'Jinbei', 'Luffy', 'Nami', 'Nico Robin', 'Zoro', 
        'Sanji', 'Chopper', 'Ussop'
    ];

    return view('mahasiswa', ['data' => $data]);
});

Route::get('/matakuliah', function () {
    $data = [
        'PBO', 'Keamanan Sistem', 'Jarkom', 'Database', 'Aljabar', 
        'Manajemen Komputer', 'RPL', 'Artifical Intelegence', 'Statistika', 'Pancasila'
    ];

    return view('matakuliah', ['data' => $data]);
});

Route::fallback(function () {
    return "Halaman yang Anda cari tidak ditemukan";
});
