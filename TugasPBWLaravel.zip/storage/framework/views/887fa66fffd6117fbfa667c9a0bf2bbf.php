<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1 class="display-4"><strong>Selamat Datang</strong></h1>
        <p class="lead">Sistem Informasi Akademik UNIVERSITAS UHUY</p>
        <hr class="my-4">
        <p>Ini adalah halaman utama Sistem Informasi Akademik UNIVERSITAS UHUY</p>
        <a class="btn btn-primary btn-lg" href="welcome" role="button">Pelajari lebih lanjut</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_informasi_akademik_2110631170155\ris\resources\views/welcome.blade.php ENDPATH**/ ?>