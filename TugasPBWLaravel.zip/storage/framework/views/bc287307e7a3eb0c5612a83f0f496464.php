<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UNIVERSITAS UHUY</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
    <!-- Navbar content -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="welcome">UNIVERSITAS UHUY</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dosen">Dosen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mahasiswa">Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="matakuliah">Matakuliah</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
<br>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<br>
   <!-- Footer content -->
<footer class="footer bg-dark text-white mt-5">
    <div class="container">
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            <p>&copy; Tugas Pemrograman Web:
                <p>Muhammad Dzaki Al Fatih</p>
                <p>4E Informatika</p>
                <p>2110631170155</p>
            </p>
        </div>
    </div>
</footer>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>



<?php /**PATH C:\xampp\htdocs\sistem_informasi_akademik_2110631170155\ris\resources\views/layouts/master.blade.php ENDPATH**/ ?>