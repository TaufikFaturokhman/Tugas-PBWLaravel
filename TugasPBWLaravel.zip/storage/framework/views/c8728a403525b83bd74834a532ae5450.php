<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1 class="display-4"><strong>Selamat Datang</strong></h1>
        <p class="lead">Sistem Informasi Akademik Npm</p>
        <hr class="my-4">
        <p>Ini adalah halaman utama Sistem Informasi Akademik Npm.</p>
        <a class="btn btn-primary btn-lg" href="welcome" role="button">Pelajari lebih lanjut</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Monkey D Botlov\Downloads\Tugas PBW_2110631170129_Risfandhiani Triara Putri\sistem_informasi_akademik_npm\resources\views/welcome.blade.php ENDPATH**/ ?>